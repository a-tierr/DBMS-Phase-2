# Car Wash Management System — Phase 2 (Maven + Hibernate)

مشروع NetBeans (Maven) بيبني كل جداول قاعدة البيانات أوتوماتيك من كلاسات الـ Entity على PostgreSQL، وبيدخل بيانات تجريبية (صفين على الأقل في كل جدول).

- **Team ID:** 83 — Mainstream — Ain Shams FCIS — DBMS
- **الجزء:** Requirement 1 (Code-first Schema: Java Integration with PostgreSQL)
- **Hibernate:** 6.4.4 (Jakarta Persistence) — **PostgreSQL driver:** 42.7.3

---

## 1) المطلوب على الجهاز

| الحاجة | الإصدار |
|---|---|
| JDK | 11 أو أحدث (مُختبر على 17) |
| NetBeans | 12.6 أو أحدث (يفضل 17+) |
| PostgreSQL | 14 أو أحدث، شغال على البورت 5432 |
| إنترنت | أول مرة بس، عشان Maven ينزّل المكتبات |

## 2) اعمل قاعدة البيانات

في pgAdmin: كليك يمين على **Databases** → **Create** → **Database** → الاسم `carwash` → Save.

أو من الـ SQL Shell / psql:

```sql
CREATE DATABASE carwash;
```

## 3) عدّل بيانات الاتصال (أهم خطوة)

الملف: `src/main/resources/hibernate.cfg.xml`

```xml
<property name="hibernate.connection.url">jdbc:postgresql://localhost:5432/carwash</property>
<property name="hibernate.connection.username">postgres</property>
<property name="hibernate.connection.password">postgres</property>
```

غيّر التلاتة دول على حسب جهازك (الباسورد بتاع `postgres` عندك، والبورت لو مش 5432).

## 4) افتح المشروع في NetBeans

1. **File → Open Project** → اختار فولدر `CarWashHibernate` (NetBeans بيعرفه Maven project لوحده).
2. استنى شريط التحميل تحت يخلص (بينزّل Hibernate والدرايفر من الإنترنت).
3. لو ظهر تحذير إن الـ JDK قديم: كليك يمين على المشروع → **Properties → Build → Compile** → خلي **Java Platform** = JDK 17.

## 5) شغّل المشروع

- كليك يمين على `src/main/java/com/team83/carwash/Main.java` → **Run File**
- أو من الـ Terminal جوه فولدر المشروع: `mvn clean compile exec:java`

## 6) هيحصل إيه بالظبط

1. Hibernate يقرأ `hibernate.cfg.xml` ويتصل بـ PostgreSQL.
2. `hibernate.hbm2ddl.auto = create` → يمسح الجداول القديمة (لو موجودة) ويعملها من جديد من كلاسات الـ Entity، وتشوف الـ DDL مطبوع في الـ Output.
3. `DataSeeder` يدخل البيانات التجريبية.
4. يطبع جدول فيه كل الجداول وعدد الصفوف، وبعدين استعلامين JOIN للتأكد إن العلاقات شغالة.

آخر سطر المفروض يكون:

```
DONE - schema created, data inserted, queries executed.
```

## 7) الجداول (11 جدول) والكلاسات

| Table | Entity | المفتاح الأساسي |
|---|---|---|
| Manager | `Manager` | Manager_ID |
| Employee | `Employee` | Employee_ID |
| Employee_Phone | `EmployeePhone` | (Employee_ID, Phone) |
| Customer | `Customer` | Customer_ID |
| Customer_Phone | `CustomerPhone` | (Customer_ID, Phone) |
| Car | `Car` | Car_ID |
| Service | `Service` | Service_ID |
| Appointment | `Appointment` | Appointment_ID |
| Appointment_Service | `AppointmentService` | (Appointment_ID, Service_ID) |
| Payment | `Payment` | Payment_ID |
| Review (weak) | `Review` | (Appointment_ID, Review_ID) |

العلاقات زي Phase 1: Customer→Car، Customer→Appointment، Car→Appointment، Employee→Appointment، Appointment↔Service (M:N مع Quantity)، Appointment→Payment (1:1)، Appointment→Review (weak entity).

## 8) حاجات مهمة في التصميم

- **الأسماء بين علامتي تنصيص** (`"Manager"`, `"Customer_ID"`) لأن Phase 1 كاتب الـ DDL كده. يعني في أي استعلام في pgAdmin لازم تكتب `SELECT * FROM "Manager";` — من غير التنصيص هيدور على جدول اسمه manager ومش هيلاقيه.
- **الـ IDs بتتكتب يدوي** (مفيش Auto Increment) لأن الـ DDL في Phase 1 معرّف `int PRIMARY KEY` عادي، مش `serial`.
- **الـ Composite FK** `(Car_ID, Customer_ID) → Car` بتاع R4 اتعمل بـ `ALTER TABLE` بعد ما Hibernate يخلص إنشاء الجداول (شوف `Main.applyPhase1CompositeForeignKey`). السبب: Hibernate مش بيعرف يبني المفتاح المركب ده من الـ mapping لأن عمود `Customer_ID` مربوط أصلاً بعلاقة الـ Customer. النتيجة نفسها: مستحيل تحجز عربية مش بتاعة العميل.
- **الصفات المشتقة** (Age, Years_of_Experience, Total_Amount) مش متخزنة في الداتابيز، محسوبة بـ getter معمول `@Transient`.
- **الـ CHECK constraints** كلها موجودة زي Phase 1 (الأسعار > 0، التقييم بين 1 و 5، حالة الحجز، …).

## 9) عايز تحتفظ بالبيانات؟

في `hibernate.cfg.xml` غيّر:

```xml
<property name="hibernate.hbm2ddl.auto">update</property>
```

`create` = يمسح ويعمل من الأول كل مرة (ده المطلوب في التسليم).
`update` = يحتفظ بالبيانات، والـ Seeder مش هيكررها.

## 10) أخطاء شائعة

| الرسالة | الحل |
|---|---|
| `FATAL: password authentication failed` | الباسورد في `hibernate.cfg.xml` غلط |
| `database "carwash" does not exist` | اعمل الداتابيز (خطوة 2) |
| `Connection refused` | PostgreSQL مش شغال، أو البورت مش 5432 |
| `Unsupported class file major version` | المشروع شغال بـ JDK قديم → غيّره لـ 17 من Properties |
| `relation "Manager" does not exist` في pgAdmin | اكتب الاسم بين تنصيص: `"Manager"` |

## 11) أسئلة محتاجة تتأكد منها مع الـ TA

1. **عدد الجداول:** الـ PDF بتاع Phase 1 بيقول 12 جدول، لكن الـ DDL المكتوب فيه **11 جدول** بس (مفيش أي جدول زيادة متعرّف). المشروع عامل الـ 11 اللي في الـ DDL — لو فيه جدول ناقص، ابعتلي الاسم ونضيفه.
2. **Payment.Amount** ممكن يختلف عن مجموع الخدمات (خصم) زي ما الـ Requirements قالت — فالـ Total مش متخزن، بيتحسب وقت الحاجة.

## 12) لو عايز تعرض المشروع

- `pom.xml` → التبعيات (Hibernate + PostgreSQL).
- `entity/` → الـ 11 كلاس + 4 كلاسات للـ composite keys في `entity/id/`.
- `hibernate.cfg.xml` → إعدادات الاتصال و `hbm2ddl`.
- `seed/DataSeeder.java` → البيانات.
- `Main.java` → التشغيل + طباعة النتيجة.

في فولدر `db/` ملف `verify.sql` فيه استعلامات جاهزة تعملها Run في pgAdmin وتاخد منها سكرين شوتس للـ Evidence.
