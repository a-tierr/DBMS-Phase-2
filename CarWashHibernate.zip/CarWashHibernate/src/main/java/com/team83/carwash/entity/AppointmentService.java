package com.team83.carwash.entity;

import com.team83.carwash.entity.id.AppointmentServiceId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import org.hibernate.annotations.Check;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

/**
 * Appointment_Service - the M:N junction between Appointment and Service (R5),
 * carrying the relationship attribute Quantity. Primary key (Appointment_ID, Service_ID).
 */
@Entity
@Table(name = "Appointment_Service")
@Check(constraints = "\"Quantity\" > 0")
public class AppointmentService implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private AppointmentServiceId id;

    @MapsId("appointmentId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Appointment_ID", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Appointment appointment;

    @MapsId("serviceId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Service_ID", nullable = false)
    @OnDelete(action = OnDeleteAction.RESTRICT)
    private Service service;

    @Column(name = "Quantity", nullable = false)
    private Integer quantity = 1;

    public AppointmentService() {
    }

    public AppointmentService(AppointmentServiceId id, Appointment appointment, Service service, Integer quantity) {
        this.id = id;
        this.appointment = appointment;
        this.service = service;
        this.quantity = quantity;
    }

    public AppointmentServiceId getId() {
        return id;
    }

    public void setId(AppointmentServiceId id) {
        this.id = id;
    }

    public Appointment getAppointment() {
        return appointment;
    }

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "AppointmentService{" + id + ", qty=" + quantity + "}";
    }
}
