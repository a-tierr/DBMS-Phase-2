package com.team83.carwash.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.Check;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Payment - at most one payment per appointment (R7).
 * The unique foreign key Appointment_ID is what makes the relationship 1:1.
 */
@Entity
@Table(name = "Payment")
@Check(constraints = "\"Amount\" > 0"
        + " AND \"Payment_Method\" IN ('Cash', 'Card', 'Wallet')"
        + " AND \"Status\" IN ('Paid', 'Refunded')")
public class Payment implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Payment_ID", nullable = false)
    private Integer paymentId;

    @Column(name = "Amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(name = "Payment_Date", nullable = false)
    private LocalDate paymentDate;

    @Column(name = "Payment_Method", nullable = false, length = 20)
    private String paymentMethod;

    @Column(name = "Status", nullable = false, length = 20)
    private String status = "Paid";

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Appointment_ID", nullable = false, unique = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Appointment appointment;

    public Payment() {
    }

    public Payment(Integer paymentId, BigDecimal amount, LocalDate paymentDate,
                   String paymentMethod, String status, Appointment appointment) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.appointment = appointment;
    }

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Appointment getAppointment() {
        return appointment;
    }

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    @Override
    public String toString() {
        return "Payment{" + paymentId + ", " + amount + ", " + paymentMethod + ", " + status + "}";
    }
}
