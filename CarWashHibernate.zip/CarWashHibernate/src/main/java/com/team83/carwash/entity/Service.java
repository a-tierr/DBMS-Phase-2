package com.team83.carwash.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.Check;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Service - the car wash catalogue. Service_Name is a candidate key and Price must be positive.
 * A service appears in many appointments through Appointment_Service (R5).
 */
@Entity
@Table(name = "Service")
@Check(constraints = "\"Price\" > 0")
public class Service implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Service_ID", nullable = false)
    private Integer serviceId;

    @Column(name = "Service_Name", nullable = false, unique = true, length = 100)
    private String serviceName;

    @Column(name = "Description", length = 255)
    private String description;

    @Column(name = "Price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @OneToMany(mappedBy = "service", fetch = FetchType.LAZY)
    private List<AppointmentService> appointmentServices = new ArrayList<>();

    public Service() {
    }

    public Service(Integer serviceId, String serviceName, String description, BigDecimal price) {
        this.serviceId = serviceId;
        this.serviceName = serviceName;
        this.description = description;
        this.price = price;
    }

    public Integer getServiceId() {
        return serviceId;
    }

    public void setServiceId(Integer serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public List<AppointmentService> getAppointmentServices() {
        return appointmentServices;
    }

    public void setAppointmentServices(List<AppointmentService> appointmentServices) {
        this.appointmentServices = appointmentServices;
    }

    @Override
    public String toString() {
        return "Service{" + serviceId + ", " + serviceName + ", " + price + "}";
    }
}
