package com.team83.carwash;

import com.team83.carwash.seed.DataSeeder;
import com.team83.carwash.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.List;

/**
 * Program entry point.
 *
 * 1. Builds the SessionFactory, which makes Hibernate run the generated DDL
 *    (hibernate.hbm2ddl.auto = create) and create the tables in PostgreSQL.
 * 2. Inserts the sample data (at least two records in every table).
 * 3. Prints the created tables with their row counts, plus two join queries
 *    so the relationships can be checked quickly.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println();
        System.out.println("==================================================================");
        System.out.println("  Car Wash Management System - Team 83");
        System.out.println("  Phase 2 - Code-first schema with Maven + Hibernate + PostgreSQL");
        System.out.println("==================================================================");

        SessionFactory sessionFactory = HibernateUtil.getSessionFactory(); // <- tables are created here

        try {
            applyPhase1CompositeForeignKey(sessionFactory);
            DataSeeder.seed(sessionFactory);
            printTableReport(sessionFactory);
            printAppointmentReport(sessionFactory);
            printReviewReport(sessionFactory);

            System.out.println();
            System.out.println("==================================================================");
            System.out.println("  DONE - schema created, data inserted, queries executed.");
            System.out.println("==================================================================");
        } finally {
            HibernateUtil.shutdown();
        }
    }

    /**
     * Phase 1 defines the relationship R4 with a composite foreign key
     * (Car_ID, Customer_ID) -> Car(Car_ID, Customer_ID), so an appointment can never
     * use a car that belongs to another customer.
     *
     * Hibernate cannot build that key from the entity mapping (Customer_ID is already
     * written by the appointment -> customer association), so the key is added with one
     * ALTER statement right after Hibernate creates the tables.
     */
    private static void applyPhase1CompositeForeignKey(SessionFactory sessionFactory) {
        String dropOld = "alter table \"Appointment\" drop constraint if exists fk_appointment_car_customer";
        String addNew = "alter table \"Appointment\" add constraint fk_appointment_car_customer "
                + "foreign key (\"Car_ID\", \"Customer_ID\") references \"Car\" (\"Car_ID\", \"Customer_ID\")";

        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.createNativeMutationQuery(dropOld).executeUpdate();
            session.createNativeMutationQuery(addNew).executeUpdate();
            tx.commit();
            System.out.println("Added the Phase 1 composite foreign key Appointment(Car_ID, Customer_ID) -> Car.");
        } catch (RuntimeException ex) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        }
    }

    private static void printTableReport(SessionFactory sessionFactory) {
        java.util.LinkedHashMap<String, Long> counts = new java.util.LinkedHashMap<>();

        try (Session session = sessionFactory.openSession()) {
            List<String> tables = session.createNativeQuery(
                    "select table_name from information_schema.tables "
                            + "where table_schema = 'public' and table_type = 'BASE TABLE' "
                            + "order by table_name", String.class).list();

            for (String table : tables) {
                Number count = (Number) session
                        .createNativeQuery("select count(*) from \"" + table + "\"")
                        .getSingleResult();
                counts.put(table, count.longValue());
            }
        }

        long total = 0;
        System.out.println();
        System.out.println("--- Tables created by Hibernate (SELECT count(*) per table) ---");
        System.out.printf("%-22s %6s%n", "TABLE", "ROWS");
        System.out.println("----------------------------");
        for (java.util.Map.Entry<String, Long> entry : counts.entrySet()) {
            total += entry.getValue();
            System.out.printf("%-22s %6d%n", entry.getKey(), entry.getValue());
        }
        System.out.println("----------------------------");
        System.out.printf("%-22s %6d   (%d tables)%n", "TOTAL", total, counts.size());
    }

    private static void printAppointmentReport(SessionFactory sessionFactory) {
        try (Session session = sessionFactory.openSession()) {
            String sql =
                    "select a.\"Appointment_ID\", "
                            + "       c.\"Fname\" || ' ' || c.\"Lname\" as customer, "
                            + "       car.\"Plate_Number\" as plate, "
                            + "       e.\"Fname\" || ' ' || e.\"Lname\" as employee, "
                            + "       a.\"Status\", "
                            + "       coalesce((select sum(s.\"Price\" * aps.\"Quantity\") "
                            + "                 from \"Appointment_Service\" aps "
                            + "                 join \"Service\" s on s.\"Service_ID\" = aps.\"Service_ID\" "
                            + "                 where aps.\"Appointment_ID\" = a.\"Appointment_ID\"), 0) as total "
                            + "from \"Appointment\" a "
                            + "join \"Customer\" c on c.\"Customer_ID\" = a.\"Customer_ID\" "
                            + "join \"Car\" car on car.\"Car_ID\" = a.\"Car_ID\" "
                            + "join \"Employee\" e on e.\"Employee_ID\" = a.\"Employee_ID\" "
                            + "order by a.\"Appointment_ID\"";

            List<Object[]> rows = session.createNativeQuery(sql).list();

            System.out.println();
            System.out.println("--- Appointments with customer, car, employee and calculated total ---");
            System.out.printf("%-4s %-16s %-10s %-16s %-12s %8s%n", "ID", "CUSTOMER", "PLATE", "EMPLOYEE", "STATUS", "TOTAL");
            System.out.println("-----------------------------------------------------------------------------");
            for (Object[] row : rows) {
                System.out.printf("%-4s %-16s %-10s %-16s %-12s %8s%n",
                        row[0], row[1], row[2], row[3], row[4], row[5]);
            }
        }
    }

    private static void printReviewReport(SessionFactory sessionFactory) {
        try (Session session = sessionFactory.openSession()) {
            String sql =
                    "select r.\"Appointment_ID\", r.\"Review_ID\", "
                            + "       c.\"Fname\" || ' ' || c.\"Lname\" as author, "
                            + "       r.\"Rating\", r.\"Comment\" "
                            + "from \"Review\" r "
                            + "join \"Customer\" c on c.\"Customer_ID\" = r.\"Customer_ID\" "
                            + "order by r.\"Appointment_ID\", r.\"Review_ID\"";

            List<Object[]> rows = session.createNativeQuery(sql).list();

            System.out.println();
            System.out.println("--- Reviews (weak entity: primary key is Appointment_ID + Review_ID) ---");
            System.out.printf("%-8s %-8s %-16s %-6s %s%n", "APPT", "REVIEW", "AUTHOR", "RATING", "COMMENT");
            System.out.println("-----------------------------------------------------------------------------");
            for (Object[] row : rows) {
                System.out.printf("%-8s %-8s %-16s %-6s %s%n", row[0], row[1], row[2], row[3], row[4]);
            }
        }
    }
}
