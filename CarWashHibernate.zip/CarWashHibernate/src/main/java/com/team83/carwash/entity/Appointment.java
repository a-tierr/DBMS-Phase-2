package com.team83.carwash.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.UniqueConstraint;
import org.hibernate.annotations.Check;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Appointment - the booking: one customer, one of that customer's cars, one employee,
 * a set of services (with quantities), at most one payment and any number of reviews.
 *
 * The pair (Car_ID, Customer_ID) is a composite foreign key to Car(Car_ID, Customer_ID),
 * which guarantees the booked car really belongs to the booking customer (R4).
 */
@Entity
@Table(name = "Appointment",
       uniqueConstraints = @UniqueConstraint(name = "uq_appointment_customer",
                                             columnNames = {"Appointment_ID", "Customer_ID"}))
@Check(constraints = "\"Status\" IN ('Pending', 'In Progress', 'Completed', 'Cancelled')")
public class Appointment implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Appointment_ID", nullable = false)
    private Integer appointmentId;

    @Column(name = "Date", nullable = false)
    private LocalDate date;

    @Column(name = "Time", nullable = false)
    private LocalTime time;

    @Column(name = "Status", nullable = false, length = 20)
    private String status = "Pending";

    /** R3: Customer Books Appointment (1:M). */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Customer_ID", nullable = false)
    private Customer customer;

    /** R4: the booked car (Car_ID -> Car). It must be one of the booking customer's cars. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Car_ID", nullable = false)
    private Car car;

    /** R6: Employee Does Appointment (1:M) - exactly one employee per appointment. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Employee_ID", nullable = false)
    private Employee employee;

    /** R5: Appointment Includes Service (M:N) with the attribute Quantity on the junction table. */
    @OneToMany(mappedBy = "appointment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AppointmentService> services = new ArrayList<>();

    /** R7: Appointment Has Payment (1:1) - the payment owns the unique foreign key. */
    @OneToOne(mappedBy = "appointment", cascade = CascadeType.ALL, orphanRemoval = true)
    private Payment payment;

    /** R8: Appointment Receives Review (1:M, identifying relationship of the weak entity). */
    @OneToMany(mappedBy = "appointment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Review> reviews = new ArrayList<>();

    public Appointment() {
    }

    public Appointment(Integer appointmentId, LocalDate date, LocalTime time, String status,
                       Customer customer, Car car, Employee employee) {
        this.appointmentId = appointmentId;
        this.date = date;
        this.time = time;
        this.status = status;
        this.customer = customer;
        this.car = car;
        this.employee = employee;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public List<AppointmentService> getServices() {
        return services;
    }

    public void setServices(List<AppointmentService> services) {
        this.services = services;
    }

    public void addService(Service service, int quantity) {
        AppointmentService line =
                new AppointmentService(new com.team83.carwash.entity.id.AppointmentServiceId(appointmentId, service.getServiceId()),
                        this, service, quantity);
        services.add(line);
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
        if (payment != null) {
            payment.setAppointment(this);
        }
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    /**
     * Derived attribute: the total of the services on this appointment.
     * It is calculated here, never stored (Payment.Amount may differ, e.g. a discount).
     */
    @Transient
    public BigDecimal getTotalAmount() {
        BigDecimal total = BigDecimal.ZERO;
        for (AppointmentService line : services) {
            if (line.getService() != null && line.getService().getPrice() != null) {
                total = total.add(line.getService().getPrice().multiply(BigDecimal.valueOf(line.getQuantity())));
            }
        }
        return total;
    }

    @Override
    public String toString() {
        return "Appointment{" + appointmentId + ", " + date + " " + time + ", " + status + "}";
    }
}
