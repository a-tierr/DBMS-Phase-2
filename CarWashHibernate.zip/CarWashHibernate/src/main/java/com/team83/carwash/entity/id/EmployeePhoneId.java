package com.team83.carwash.entity.id;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

/** Composite primary key of Employee_Phone: (Employee_ID, Phone). */
@Embeddable
public class EmployeePhoneId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "Employee_ID", nullable = false)
    private Integer employeeId;

    @Column(name = "Phone", nullable = false, length = 20)
    private String phone;

    public EmployeePhoneId() {
    }

    public EmployeePhoneId(Integer employeeId, String phone) {
        this.employeeId = employeeId;
        this.phone = phone;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmployeePhoneId)) return false;
        EmployeePhoneId that = (EmployeePhoneId) o;
        return Objects.equals(employeeId, that.employeeId) && Objects.equals(phone, that.phone);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId, phone);
    }
}
