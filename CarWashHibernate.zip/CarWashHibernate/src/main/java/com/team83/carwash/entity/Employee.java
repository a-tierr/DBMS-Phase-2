package com.team83.carwash.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.Check;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

/**
 * Employee - works for at most one manager and handles many appointments.
 * Address is a composite attribute, flattened into Street / City / Governorate.
 * Phone is multivalued, stored in the Employee_Phone table.
 */
@Entity
@Table(name = "Employee")
@Check(constraints = "\"Salary\" > 0 AND \"Bonus\" >= 0 AND \"Hire_Date\" > \"Birth_Date\"")
public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Employee_ID", nullable = false)
    private Integer employeeId;

    @Column(name = "Fname", nullable = false, length = 50)
    private String fname;

    @Column(name = "Lname", nullable = false, length = 50)
    private String lname;

    @Column(name = "Salary", nullable = false, precision = 10, scale = 2)
    private BigDecimal salary;

    @Column(name = "Bonus", precision = 10, scale = 2)
    private BigDecimal bonus = BigDecimal.ZERO;

    @Column(name = "Hire_Date", nullable = false)
    private LocalDate hireDate;

    @Column(name = "Birth_Date", nullable = false)
    private LocalDate birthDate;

    @Column(name = "Street", length = 100)
    private String street;

    @Column(name = "City", length = 50)
    private String city;

    @Column(name = "Governorate", length = 50)
    private String governorate;

    /** R1: many employees are supervised by one manager (nullable: an employee may have no manager). */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Manager_ID")
    @OnDelete(action = OnDeleteAction.SET_NULL)
    private Manager manager;

    /** Multivalued attribute Phone -> Employee_Phone table. */
    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<EmployeePhone> phones = new ArrayList<>();

    /** R6: Employee Does Appointment (1:M). */
    @OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
    private List<Appointment> appointments = new ArrayList<>();

    public Employee() {
    }

    public Employee(Integer employeeId, String fname, String lname, BigDecimal salary, BigDecimal bonus,
                    LocalDate hireDate, LocalDate birthDate,
                    String street, String city, String governorate) {
        this.employeeId = employeeId;
        this.fname = fname;
        this.lname = lname;
        this.salary = salary;
        this.bonus = bonus;
        this.hireDate = hireDate;
        this.birthDate = birthDate;
        this.street = street;
        this.city = city;
        this.governorate = governorate;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public BigDecimal getBonus() {
        return bonus;
    }

    public void setBonus(BigDecimal bonus) {
        this.bonus = bonus;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getGovernorate() {
        return governorate;
    }

    public void setGovernorate(String governorate) {
        this.governorate = governorate;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public List<EmployeePhone> getPhones() {
        return phones;
    }

    public void setPhones(List<EmployeePhone> phones) {
        this.phones = phones;
    }

    public void addPhone(String phone) {
        EmployeePhone p = new EmployeePhone(new com.team83.carwash.entity.id.EmployeePhoneId(employeeId, phone), this);
        phones.add(p);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    /** Derived attribute (not a column). */
    @Transient
    public int getAge() {
        return birthDate == null ? 0 : Period.between(birthDate, LocalDate.now()).getYears();
    }

    /** Derived attribute (not a column). */
    @Transient
    public int getYearsOfExperience() {
        return hireDate == null ? 0 : Period.between(hireDate, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "Employee{" + employeeId + ", " + fname + " " + lname + "}";
    }
}
