package com.team83.carwash.entity.id;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

/** Composite primary key of Customer_Phone: (Customer_ID, Phone). */
@Embeddable
public class CustomerPhoneId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "Customer_ID", nullable = false)
    private Integer customerId;

    @Column(name = "Phone", nullable = false, length = 20)
    private String phone;

    public CustomerPhoneId() {
    }

    public CustomerPhoneId(Integer customerId, String phone) {
        this.customerId = customerId;
        this.phone = phone;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CustomerPhoneId)) return false;
        CustomerPhoneId that = (CustomerPhoneId) o;
        return Objects.equals(customerId, that.customerId) && Objects.equals(phone, that.phone);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, phone);
    }
}
