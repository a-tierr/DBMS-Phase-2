package com.team83.carwash.entity.id;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

/**
 * Composite primary key of the weak entity Review: (Appointment_ID, Review_ID).
 * Appointment_ID comes from the identifying relationship "Receives";
 * Review_ID is the partial key that is unique only inside one appointment.
 */
@Embeddable
public class ReviewId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "Appointment_ID", nullable = false)
    private Integer appointmentId;

    @Column(name = "Review_ID", nullable = false)
    private Integer reviewId;

    public ReviewId() {
    }

    public ReviewId(Integer appointmentId, Integer reviewId) {
        this.appointmentId = appointmentId;
        this.reviewId = reviewId;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Integer getReviewId() {
        return reviewId;
    }

    public void setReviewId(Integer reviewId) {
        this.reviewId = reviewId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReviewId)) return false;
        ReviewId that = (ReviewId) o;
        return Objects.equals(appointmentId, that.appointmentId) && Objects.equals(reviewId, that.reviewId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId, reviewId);
    }
}
