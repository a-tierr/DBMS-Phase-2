package com.team83.carwash.entity.id;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

/** Composite primary key of Appointment_Service: (Appointment_ID, Service_ID). */
@Embeddable
public class AppointmentServiceId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "Appointment_ID", nullable = false)
    private Integer appointmentId;

    @Column(name = "Service_ID", nullable = false)
    private Integer serviceId;

    public AppointmentServiceId() {
    }

    public AppointmentServiceId(Integer appointmentId, Integer serviceId) {
        this.appointmentId = appointmentId;
        this.serviceId = serviceId;
    }

    public Integer getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Integer appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Integer getServiceId() {
        return serviceId;
    }

    public void setServiceId(Integer serviceId) {
        this.serviceId = serviceId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AppointmentServiceId)) return false;
        AppointmentServiceId that = (AppointmentServiceId) o;
        return Objects.equals(appointmentId, that.appointmentId) && Objects.equals(serviceId, that.serviceId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId, serviceId);
    }
}
