package com.team83.carwash.entity;

import com.team83.carwash.entity.id.CustomerPhoneId;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

/**
 * Customer_Phone - the multivalued attribute Phone of Customer.
 * Composite primary key (Customer_ID, Phone); Customer_ID is also a foreign key
 * with ON DELETE CASCADE, so a customer's phones disappear with the customer.
 */
@Entity
@Table(name = "Customer_Phone")
public class CustomerPhone implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private CustomerPhoneId id;

    @MapsId("customerId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Customer_ID", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Customer customer;

    public CustomerPhone() {
    }

    public CustomerPhone(CustomerPhoneId id, Customer customer) {
        this.id = id;
        this.customer = customer;
    }

    public CustomerPhoneId getId() {
        return id;
    }

    public void setId(CustomerPhoneId id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /** Convenience accessor for the phone value (it is already mapped inside the composite id). */
    @Transient
    public String getPhone() {
        return id == null ? null : id.getPhone();
    }

    @Override
    public String toString() {
        return "CustomerPhone{" + getPhone() + "}";
    }
}
