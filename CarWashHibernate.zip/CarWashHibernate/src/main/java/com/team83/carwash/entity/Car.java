package com.team83.carwash.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import org.hibernate.annotations.Check;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Car - belongs to exactly one customer (R2).
 * Plate_Number is a candidate key. The unique pair (Car_ID, Customer_ID) is what
 * Appointment references, so an appointment can never use another customer's car.
 */
@Entity
@Table(name = "Car",
       uniqueConstraints = @UniqueConstraint(name = "uq_car_customer", columnNames = {"Car_ID", "Customer_ID"}))
@Check(constraints = "\"Size\" IN ('Small', 'Medium', 'Large')")
public class Car implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Car_ID", nullable = false)
    private Integer carId;

    @Column(name = "Plate_Number", nullable = false, unique = true, length = 20)
    private String plateNumber;

    @Column(name = "Model", nullable = false, length = 50)
    private String model;

    @Column(name = "Color", length = 30)
    private String color;

    @Column(name = "Size", length = 10)
    private String size;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Customer_ID", nullable = false)
    private Customer customer;

    /** R4: Car Has Appointment (1:M). */
    @OneToMany(mappedBy = "car", fetch = FetchType.LAZY)
    private List<Appointment> appointments = new ArrayList<>();

    public Car() {
    }

    public Car(Integer carId, String plateNumber, String model, String color, String size, Customer customer) {
        this.carId = carId;
        this.plateNumber = plateNumber;
        this.model = model;
        this.color = color;
        this.size = size;
        this.customer = customer;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    @Override
    public String toString() {
        return "Car{" + carId + ", " + plateNumber + "}";
    }
}
