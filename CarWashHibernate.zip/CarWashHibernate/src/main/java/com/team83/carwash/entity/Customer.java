package com.team83.carwash.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import org.hibernate.annotations.Check;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Customer - owns cars, books appointments and writes reviews.
 * Name is composite (Fname, Lname); Phone is multivalued (Customer_Phone table);
 * Visit_Points must never be negative.
 */
@Entity
@Table(name = "Customer")
@Check(constraints = "\"Visit_Points\" >= 0")
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Customer_ID", nullable = false)
    private Integer customerId;

    @Column(name = "Fname", nullable = false, length = 50)
    private String fname;

    @Column(name = "Lname", nullable = false, length = 50)
    private String lname;

    @Column(name = "Visit_Points", nullable = false)
    private Integer visitPoints = 0;

    /** Multivalued attribute Phone -> Customer_Phone table. */
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<CustomerPhone> phones = new ArrayList<>();

    /** R2: Customer Owns Car (1:M). */
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<Car> cars = new ArrayList<>();

    /** R3: Customer Books Appointment (1:M). */
    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
    private List<Appointment> appointments = new ArrayList<>();

    /** R9: Customer Writes Review (1:M). */
    @OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
    private List<Review> reviews = new ArrayList<>();

    public Customer() {
    }

    public Customer(Integer customerId, String fname, String lname, Integer visitPoints) {
        this.customerId = customerId;
        this.fname = fname;
        this.lname = lname;
        this.visitPoints = visitPoints;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public Integer getVisitPoints() {
        return visitPoints;
    }

    public void setVisitPoints(Integer visitPoints) {
        this.visitPoints = visitPoints;
    }

    public List<CustomerPhone> getPhones() {
        return phones;
    }

    public void setPhones(List<CustomerPhone> phones) {
        this.phones = phones;
    }

    public void addPhone(String phone) {
        phones.add(new CustomerPhone(new com.team83.carwash.entity.id.CustomerPhoneId(customerId, phone), this));
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }

    public void addCar(Car car) {
        cars.add(car);
        car.setCustomer(this);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void setAppointments(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @Override
    public String toString() {
        return "Customer{" + customerId + ", " + fname + " " + lname + "}";
    }
}
