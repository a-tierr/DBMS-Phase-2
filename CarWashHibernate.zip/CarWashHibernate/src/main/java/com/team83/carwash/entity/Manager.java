package com.team83.carwash.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import org.hibernate.annotations.Check;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

/**
 * Manager - supervises employees (1:M).
 * Table "Manager": Manager_ID (PK), Fname + Lname (composite name), SSN (candidate key),
 * Hire_Date, Birth_Date. Age is a derived attribute, so it is not stored.
 */
@Entity
@Table(name = "Manager")
@Check(constraints = "\"Hire_Date\" > \"Birth_Date\"")
public class Manager implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "Manager_ID", nullable = false)
    private Integer managerId;

    @Column(name = "Fname", nullable = false, length = 50)
    private String fname;

    @Column(name = "Lname", nullable = false, length = 50)
    private String lname;

    @Column(name = "SSN", nullable = false, unique = true, length = 20)
    private String ssn;

    @Column(name = "Hire_Date", nullable = false)
    private LocalDate hireDate;

    @Column(name = "Birth_Date", nullable = false)
    private LocalDate birthDate;

    /** R1: Manager Supervises Employee (1:M). The foreign key lives in Employee.Manager_ID. */
    @OneToMany(mappedBy = "manager", fetch = FetchType.LAZY)
    private List<Employee> employees = new ArrayList<>();

    public Manager() {
    }

    public Manager(Integer managerId, String fname, String lname, String ssn,
                   LocalDate hireDate, LocalDate birthDate) {
        this.managerId = managerId;
        this.fname = fname;
        this.lname = lname;
        this.ssn = ssn;
        this.hireDate = hireDate;
        this.birthDate = birthDate;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
        employee.setManager(this);
    }

    /** Derived attribute (not a column). */
    @Transient
    public int getAge() {
        return birthDate == null ? 0 : Period.between(birthDate, LocalDate.now()).getYears();
    }

    @Override
    public String toString() {
        return "Manager{" + managerId + ", " + fname + " " + lname + "}";
    }
}
