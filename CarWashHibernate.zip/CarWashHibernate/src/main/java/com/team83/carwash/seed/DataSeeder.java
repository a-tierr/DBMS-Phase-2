package com.team83.carwash.seed;

import com.team83.carwash.entity.Appointment;
import com.team83.carwash.entity.AppointmentService;
import com.team83.carwash.entity.Car;
import com.team83.carwash.entity.Customer;
import com.team83.carwash.entity.CustomerPhone;
import com.team83.carwash.entity.Employee;
import com.team83.carwash.entity.EmployeePhone;
import com.team83.carwash.entity.Manager;
import com.team83.carwash.entity.Payment;
import com.team83.carwash.entity.Review;
import com.team83.carwash.entity.Service;
import com.team83.carwash.entity.id.AppointmentServiceId;
import com.team83.carwash.entity.id.CustomerPhoneId;
import com.team83.carwash.entity.id.EmployeePhoneId;
import com.team83.carwash.entity.id.ReviewId;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Inserts the sample data required by Phase 2: at least two records in every table.
 * The rows follow the rules of Phase 1: a car always belongs to its booking customer,
 * every appointment has one employee and at least one service, one payment per appointment.
 */
public final class DataSeeder {

    private DataSeeder() {
    }

    public static void seed(SessionFactory sessionFactory) {
        Session session = sessionFactory.openSession();

        // With hbm2ddl.auto = create the tables are always empty here. With update they are
        // kept, so the sample rows are only inserted once.
        Number existing = (Number) session.createNativeQuery("select count(*) from \"Customer\"").getSingleResult();
        if (existing.longValue() > 0) {
            session.close();
            System.out.println("Seed data already present (" + existing.longValue()
                    + " customers), skipping the insert. Use hbm2ddl.auto = create for a clean database.");
            return;
        }

        Transaction tx = session.beginTransaction();
        try {
            // ---------- Manager (2 rows) ----------
            Manager ahmed = new Manager(1, "Ahmed", "Hassan", "28401011234567",
                    LocalDate.of(2015, 3, 1), LocalDate.of(1984, 1, 12));
            Manager mona = new Manager(2, "Mona", "Sabry", "28905152345678",
                    LocalDate.of(2019, 7, 15), LocalDate.of(1989, 5, 23));
            session.persist(ahmed);
            session.persist(mona);

            // ---------- Employee (3 rows) + Employee_Phone (4 rows) ----------
            Employee karim = new Employee(1, "Karim", "Adel", new BigDecimal("4500.00"), new BigDecimal("300.00"),
                    LocalDate.of(2020, 2, 10), LocalDate.of(1996, 6, 5),
                    "12 El-Horreya St", "Giza", "Giza");
            karim.setManager(ahmed);

            Employee salma = new Employee(2, "Salma", "Nabil", new BigDecimal("4800.00"), new BigDecimal("250.00"),
                    LocalDate.of(2021, 9, 1), LocalDate.of(1997, 11, 19),
                    "5 Makram Ebeid St", "Nasr City", "Cairo");
            salma.setManager(ahmed);

            Employee hany = new Employee(3, "Hany", "Fouad", new BigDecimal("4200.00"), BigDecimal.ZERO,
                    LocalDate.of(2023, 4, 20), LocalDate.of(2000, 2, 14),
                    "8 El-Salam St", "Faisal", "Giza");
            hany.setManager(mona);

            session.persist(karim);
            session.persist(salma);
            session.persist(hany);

            session.persist(new EmployeePhone(new EmployeePhoneId(1, "01001112233"), karim));
            session.persist(new EmployeePhone(new EmployeePhoneId(1, "01112223344"), karim));
            session.persist(new EmployeePhone(new EmployeePhoneId(2, "01234567890"), salma));
            session.persist(new EmployeePhone(new EmployeePhoneId(3, "01098765432"), hany));
            session.flush();

            // ---------- Customer (3 rows) + Customer_Phone (4 rows) ----------
            Customer omar = new Customer(1, "Omar", "Khaled", 120);
            Customer nada = new Customer(2, "Nada", "Fathy", 45);
            Customer youssef = new Customer(3, "Youssef", "Ibrahim", 0);
            session.persist(omar);
            session.persist(nada);
            session.persist(youssef);

            session.persist(new CustomerPhone(new CustomerPhoneId(1, "01001234567"), omar));
            session.persist(new CustomerPhone(new CustomerPhoneId(1, "01109876543"), omar));
            session.persist(new CustomerPhone(new CustomerPhoneId(2, "01223334444"), nada));
            session.persist(new CustomerPhone(new CustomerPhoneId(3, "01555667788"), youssef));
            session.flush();

            // ---------- Car (4 rows) ----------
            Car corolla = new Car(1, "ABC-123", "Toyota Corolla", "White", "Medium", omar);
            Car elantra = new Car(2, "XYZ-987", "Hyundai Elantra", "Black", "Medium", omar);
            Car picanto = new Car(3, "QWE-456", "Kia Picanto", "Silver", "Small", nada);
            Car jeep = new Car(4, "RTY-321", "Jeep Grand Cherokee", "Blue", "Large", youssef);
            session.persist(corolla);
            session.persist(elantra);
            session.persist(picanto);
            session.persist(jeep);

            // ---------- Service (3 rows) ----------
            Service exterior = new Service(1, "Exterior Wash", "Full exterior wash with foam and rinse", new BigDecimal("60.00"));
            Service interior = new Service(2, "Interior Cleaning", "Vacuum and interior wipe", new BigDecimal("80.00"));
            Service engine = new Service(3, "Engine Wash", "Engine bay degreasing", new BigDecimal("150.00"));
            session.persist(exterior);
            session.persist(interior);
            session.persist(engine);
            session.flush();

            // ---------- Appointment (4 rows) ----------
            Appointment a1 = new Appointment(1, LocalDate.of(2026, 11, 20), LocalTime.of(10, 0), "Completed", omar, corolla, karim);
            Appointment a2 = new Appointment(2, LocalDate.of(2026, 11, 22), LocalTime.of(12, 30), "Completed", nada, picanto, salma);
            Appointment a3 = new Appointment(3, LocalDate.of(2026, 11, 25), LocalTime.of(9, 15), "Pending", omar, elantra, hany);
            Appointment a4 = new Appointment(4, LocalDate.of(2026, 11, 26), LocalTime.of(16, 0), "In Progress", youssef, jeep, karim);
            session.persist(a1);
            session.persist(a2);
            session.persist(a3);
            session.persist(a4);
            session.flush();

            // ---------- Appointment_Service (6 rows, M:N with Quantity) ----------
            session.persist(new AppointmentService(new AppointmentServiceId(1, 1), a1, exterior, 1));
            session.persist(new AppointmentService(new AppointmentServiceId(1, 2), a1, interior, 1));
            session.persist(new AppointmentService(new AppointmentServiceId(2, 1), a2, exterior, 2));
            session.persist(new AppointmentService(new AppointmentServiceId(3, 3), a3, engine, 1));
            session.persist(new AppointmentService(new AppointmentServiceId(4, 1), a4, exterior, 1));
            session.persist(new AppointmentService(new AppointmentServiceId(4, 2), a4, interior, 1));
            session.flush();

            // ---------- Payment (3 rows, one per appointment at most) ----------
            session.persist(new Payment(1, new BigDecimal("140.00"), LocalDate.of(2026, 11, 20), "Card", "Paid", a1));
            session.persist(new Payment(2, new BigDecimal("120.00"), LocalDate.of(2026, 11, 22), "Cash", "Paid", a2));
            session.persist(new Payment(3, new BigDecimal("90.00"), LocalDate.of(2026, 11, 21), "Wallet", "Refunded", a3));
            session.flush();

            // ---------- Review (3 rows, weak entity: (Appointment_ID, Review_ID)) ----------
            session.persist(new Review(new ReviewId(1, 1), a1, omar,
                    new BigDecimal("5.0"), "Fast service and the car looked new.", LocalDate.of(2026, 11, 20)));
            session.persist(new Review(new ReviewId(1, 2), a1, omar,
                    new BigDecimal("4.0"), "Second review on the same visit: waiting area needs work.", LocalDate.of(2026, 11, 21)));
            session.persist(new Review(new ReviewId(2, 1), a2, nada,
                    new BigDecimal("4.5"), "Good wash, friendly staff.", LocalDate.of(2026, 11, 22)));

            tx.commit();
            System.out.println("Seed data inserted.");
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        } finally {
            session.close();
        }
    }
}
