package com.team83.carwash.entity;

import com.team83.carwash.entity.id.ReviewId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.Check;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Review - the weak entity of the model.
 *
 * It has no key of its own: Review_ID is only a partial key, unique inside one
 * appointment, so the primary key is (Appointment_ID, Review_ID). Appointment_ID
 * comes from the identifying relationship "Receives" (R8), and the extra foreign
 * key Customer_ID comes from R9 (Customer Writes Review). Because Appointment is
 * unique on (Appointment_ID, Customer_ID), the review can only be written by the
 * customer who booked that appointment.
 */
@Entity
@Table(name = "Review")
@Check(constraints = "\"Rating\" BETWEEN 1 AND 5")
public class Review implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private ReviewId id;

    @Column(name = "Rating", nullable = false, precision = 2, scale = 1)
    private BigDecimal rating;

    @Column(name = "Comment", length = 255)
    private String comment;

    @Column(name = "Review_Date", nullable = false)
    private LocalDate reviewDate;

    /** R9: Customer Writes Review (1:M). */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Customer_ID", nullable = false)
    private Customer customer;

    /** R8: identifying relationship - (Appointment_ID, Customer_ID) -> Appointment. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumns({
        @JoinColumn(name = "Appointment_ID", referencedColumnName = "Appointment_ID",
                    insertable = false, updatable = false),
        @JoinColumn(name = "Customer_ID", referencedColumnName = "Customer_ID",
                    insertable = false, updatable = false)
    })
    private Appointment appointment;

    public Review() {
    }

    public Review(ReviewId id, Appointment appointment, Customer customer,
                  BigDecimal rating, String comment, LocalDate reviewDate) {
        this.id = id;
        this.appointment = appointment;
        this.customer = customer;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = reviewDate;
    }

    public ReviewId getId() {
        return id;
    }

    public void setId(ReviewId id) {
        this.id = id;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDate getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(LocalDate reviewDate) {
        this.reviewDate = reviewDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Appointment getAppointment() {
        return appointment;
    }

    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    @Override
    public String toString() {
        return "Review{" + id + ", rating=" + rating + "}";
    }
}
