package com.team83.carwash.entity;

import com.team83.carwash.entity.id.EmployeePhoneId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.io.Serializable;

/**
 * Employee_Phone - the multivalued attribute Phone of Employee.
 * Composite primary key (Employee_ID, Phone); Employee_ID is also a foreign key.
 */
@Entity
@Table(name = "Employee_Phone")
public class EmployeePhone implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private EmployeePhoneId id;

    @MapsId("employeeId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "Employee_ID", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Employee employee;

    public EmployeePhone() {
    }

    public EmployeePhone(EmployeePhoneId id, Employee employee) {
        this.id = id;
        this.employee = employee;
    }

    public EmployeePhoneId getId() {
        return id;
    }

    public void setId(EmployeePhoneId id) {
        this.id = id;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    /** Convenience accessor for the phone value (it is already mapped inside the composite id). */
    @jakarta.persistence.Transient
    public String getPhone() {
        return id == null ? null : id.getPhone();
    }

    @Override
    public String toString() {
        return "EmployeePhone{" + getPhone() + "}";
    }
}
