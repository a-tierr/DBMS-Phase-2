-- استعلامات جاهزة للـ Evidence (شغّلها في pgAdmin Query Tool بعد تشغيل المشروع)

-- 1) قائمة الجداول اللي Hibernate عملها
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
ORDER BY table_name;

-- 2) عدد الصفوف في كل جدول (لازم 2 على الأقل في كل واحد)
SELECT 'Manager' AS table_name, count(*) FROM "Manager"
UNION ALL SELECT 'Employee', count(*) FROM "Employee"
UNION ALL SELECT 'Employee_Phone', count(*) FROM "Employee_Phone"
UNION ALL SELECT 'Customer', count(*) FROM "Customer"
UNION ALL SELECT 'Customer_Phone', count(*) FROM "Customer_Phone"
UNION ALL SELECT 'Car', count(*) FROM "Car"
UNION ALL SELECT 'Service', count(*) FROM "Service"
UNION ALL SELECT 'Appointment', count(*) FROM "Appointment"
UNION ALL SELECT 'Appointment_Service', count(*) FROM "Appointment_Service"
UNION ALL SELECT 'Payment', count(*) FROM "Payment"
UNION ALL SELECT 'Review', count(*) FROM "Review"
ORDER BY 1;

-- 3) الحجوزات مع العميل والعربية والموظف والمجموع المحسوب
SELECT a."Appointment_ID",
       c."Fname" || ' ' || c."Lname" AS customer,
       car."Plate_Number"            AS plate,
       e."Fname" || ' ' || e."Lname" AS employee,
       a."Status",
       COALESCE((SELECT SUM(s."Price" * aps."Quantity")
                 FROM "Appointment_Service" aps
                 JOIN "Service" s ON s."Service_ID" = aps."Service_ID"
                 WHERE aps."Appointment_ID" = a."Appointment_ID"), 0) AS total
FROM "Appointment" a
JOIN "Customer" c ON c."Customer_ID" = a."Customer_ID"
JOIN "Car" car    ON car."Car_ID" = a."Car_ID"
JOIN "Employee" e ON e."Employee_ID" = a."Employee_ID"
ORDER BY a."Appointment_ID";

-- 4) الـ Review (weak entity: المفتاح (Appointment_ID, Review_ID))
SELECT r."Appointment_ID", r."Review_ID", c."Fname" || ' ' || c."Lname" AS author,
       r."Rating", r."Review_Date", r."Comment"
FROM "Review" r
JOIN "Customer" c ON c."Customer_ID" = r."Customer_ID"
ORDER BY r."Appointment_ID", r."Review_ID";

-- 5) كل القيود (PK / FK / UNIQUE / CHECK) عشان سكرين شوت الـ schema
SELECT conrelid::regclass AS table_name, conname, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE connamespace = 'public'::regnamespace
ORDER BY 1, 2;
